# spoticfy

## Integrantes:

- Luca M.
- Asael B.
- Juan Martin A.

## Aclaraciones

Todos las queries las cuales tienen despues un SELECT * FROM es para checkear el funcionamiento con las consola.